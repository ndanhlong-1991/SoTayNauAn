# Sổ Tay Nấu Ăn Pro 5.0

Ứng dụng Android gốc (Java, không dùng WebView). Package giữ nguyên `com.sotaynauan.app` và đọc dữ liệu cũ từ SharedPreferences `MonAn` / `data`.

## Giao diện và chức năng
Trang chủ ảnh món ăn, danh mục, thẻ công thức, tìm kiếm, món yêu thích. Màn hình thêm và sửa công thức với: tên, mô tả, ảnh, video, khẩu phần, thời gian chuẩn bị/nấu, độ khó, từng nguyên liệu với tên/số lượng/đơn vị/chất lượng, từng bước chế biến, ghi chú và lưu ý quan trọng. Màn chi tiết có các tab: Tổng quan, Nguyên liệu, Cách làm, Ghi chú, Video. Có nút phát video và sao lưu/khôi phục ZIP kèm ảnh và video.

## Cập nhật qua điện thoại
Giải nén ZIP; tải từng file lên **đúng đường dẫn** của repository GitHub đang dùng. Lưu ý file ZIP tải vào repo trực tiếp sẽ không tự giải nén. Nếu chỉ muốn xem giao diện mới trước, cập nhật `app/src/main/java/com/sotaynauan/app/MainActivity.java`; để có biểu tượng ngoài màn hình, cần cập nhật thêm AndroidManifest.xml và các file ic_launcher.png ở đúng các thư mục mipmap.

GitHub Actions tự tạo APK bằng `gradle assembleDebug`. **Chưa chạy build Android thực tế trong môi trường tạo gói**; kiểm tra Actions xem có lỗi biên dịch không.

**Quan trọng:** APK debug ở hai lần build có thể có chữ ký khác nhau. Trước khi gỡ app cũ, hãy sao lưu dữ liệu trong app (nếu có). Không gỡ ứng dụng trước khi sao lưu.
