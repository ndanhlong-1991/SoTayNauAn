package com.sotaynauan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQUEST_PHOTO = 101;
    private static final int REQUEST_EXPORT = 102;
    private static final int REQUEST_IMPORT = 103;

    private static final int CREAM = Color.rgb(255, 249, 241);
    private static final int WHITE = Color.WHITE;
    private static final int INK = Color.rgb(42, 39, 34);
    private static final int MUTED = Color.rgb(127, 117, 108);
    private static final int RUST = Color.rgb(191, 70, 39);
    private static final int ORANGE = Color.rgb(226, 112, 55);
    private static final int GREEN = Color.rgb(49, 100, 76);
    private static final int LINE = Color.rgb(232, 222, 211);
    private static final int PALE = Color.rgb(253, 239, 225);

    private static final String[] CATEGORIES =
        {"Món Việt", "Món Âu", "Món Á", "Món chay", "Khác"};
    private static final String[] FILTERS =
        {"Tất cả", "Món Việt", "Món Âu", "Món Á", "Món chay", "Khác"};

    private SharedPreferences store;
    private JSONArray recipes;
    private LinearLayout root, list, editor, photoArea, filterRow;
    private ScrollView scrollView;
    private EditText search, nameInput, ingredientInput, instructionInput;
    private Spinner categorySpinner;
    private TextView summary, countBadge, editorTitle;
    private String activeFilter = "Tất cả";
    private int editingIndex = -1;
    private String selectedPhoto = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(CREAM);
        getWindow().setNavigationBarColor(Color.rgb(30, 30, 30));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        store = getSharedPreferences("MonAn", MODE_PRIVATE);
        try {
            recipes = new JSONArray(store.getString("data", "[]"));
        } catch (Exception ignored) {
            recipes = new JSONArray();
        }
        buildScreen();
        refreshList();
    }

    private int dp(float size) {
        return (int)(size * getResources().getDisplayMetrics().density + .5f);
    }

    private GradientDrawable rounded(int fill, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable outlined(int fill, int radius, int stroke) {
        GradientDrawable d = rounded(fill, radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private GradientDrawable gradient(int first, int second, int radius) {
        GradientDrawable d = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, new int[]{first, second});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams outside(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private LinearLayout.LayoutParams weighted(float weight, int right) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight);
        p.setMargins(0, 0, dp(right), 0);
        return p;
    }

    private Button btn(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(14);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(rounded(bg, 14));
        b.setBackgroundTintList((ColorStateList)null);
        b.setStateListAnimator(null);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setMinHeight(dp(46));
        return b;
    }

    private void buildScreen() {
        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setBackgroundColor(CREAM);
        root = column();
        root.setPadding(dp(20), dp(24), dp(20), dp(40));
        scrollView.addView(root);
        setContentView(scrollView);

        // BRAND HEADER
        LinearLayout top = row();
        root.addView(top, outside(0, 22));
        TextView logo = label("🍳", 25, WHITE, false);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(gradient(ORANGE, RUST, 18));
        top.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout names = column();
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, -2, 1);
        nameParams.setMargins(dp(12), 0, dp(8), 0);
        top.addView(names, nameParams);
        names.addView(label("GÓC BẾP CỦA BẠN", 11, RUST, true));
        names.addView(label("Sổ Tay Nấu Ăn", 23, INK, true));
        countBadge = label("0 món", 12, GREEN, true);
        countBadge.setPadding(dp(10), dp(8), dp(10), dp(8));
        countBadge.setBackground(rounded(Color.rgb(231, 242, 230), 30));
        top.addView(countBadge);

        // HERO
        LinearLayout hero = row();
        hero.setPadding(dp(18), dp(22), dp(16), dp(22));
        hero.setBackground(gradient(RUST, ORANGE, 22));
        hero.setElevation(dp(3));
        root.addView(hero, outside(0, 20));
        LinearLayout heroText = column();
        hero.addView(heroText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView tiny = label("✨  MỖI NGÀY MỘT MÓN NGON", 11, Color.rgb(255, 233, 212), true);
        heroText.addView(tiny);
        heroText.addView(label("Hôm nay\nmình nấu gì?", 28, WHITE, true), outside(10, 7));
        heroText.addView(label("Lưu trọn hương vị bếp nhà.", 13, Color.rgb(255, 240, 226), false));
        TextView dish = label("🥘", 53, WHITE, false);
        dish.setGravity(Gravity.CENTER);
        hero.addView(dish, new LinearLayout.LayoutParams(dp(80), dp(100)));

        // SEARCH
        LinearLayout searchBox = row();
        searchBox.setPadding(dp(14), dp(5), dp(12), dp(5));
        searchBox.setBackground(outlined(WHITE, 17, LINE));
        searchBox.setElevation(dp(1));
        root.addView(searchBox, outside(0, 17));
        searchBox.addView(label("⌕", 28, RUST, true));
        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(INK);
        search.setHintTextColor(MUTED);
        search.setHint("  Tìm tên món, nguyên liệu...");
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setPadding(dp(4), dp(5), dp(4), dp(5));
        searchBox.addView(search, new LinearLayout.LayoutParams(0, dp(44), 1));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { refreshList(); }
            public void afterTextChanged(Editable e) {}
        });

        // CATEGORY FILTER PILLS
        root.addView(label("Khám phá theo danh mục", 15, INK, true), outside(0, 11));
        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        horizontal.setClipToPadding(false);
        root.addView(horizontal, outside(0, 17));
        filterRow = row();
        horizontal.addView(filterRow);
        refreshFilters();

        Button newRecipe = btn("＋   Thêm công thức mới", RUST, WHITE);
        root.addView(newRecipe, outside(0, 12));
        newRecipe.setOnClickListener(v -> {
            if (editor.getVisibility() == View.VISIBLE && editingIndex == -1) {
                editor.setVisibility(View.GONE);
            } else {
                clearEditor();
                editor.setVisibility(View.VISIBLE);
                scrollView.post(() -> scrollView.smoothScrollTo(0, editor.getTop()));
            }
        });

        // RECIPE EDITOR
        editor = column();
        editor.setPadding(dp(17), dp(16), dp(17), dp(18));
        editor.setBackground(outlined(WHITE, 18, LINE));
        editor.setElevation(dp(2));
        root.addView(editor, outside(4, 16));
        LinearLayout editHead = row();
        editor.addView(editHead, outside(0, 12));
        editorTitle = label("Thêm công thức", 20, INK, true);
        editHead.addView(editorTitle, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = label("✕", 19, MUTED, true);
        close.setPadding(dp(10), dp(5), dp(5), dp(5));
        editHead.addView(close);
        close.setOnClickListener(v -> { clearEditor(); editor.setVisibility(View.GONE); });
        editor.addView(label("Tên món ăn", 13, MUTED, true), outside(1, 7));
        nameInput = field("Ví dụ: Vịt cà ri", 1);
        editor.addView(nameInput, outside(0, 13));
        editor.addView(label("Nguyên liệu", 13, MUTED, true), outside(0, 7));
        ingredientInput = field("Nhập nguyên liệu và định lượng", 3);
        editor.addView(ingredientInput, outside(0, 13));
        editor.addView(label("Các bước chế biến", 13, MUTED, true), outside(0, 7));
        instructionInput = field("Viết các bước nấu ăn...", 4);
        editor.addView(instructionInput, outside(0, 13));
        editor.addView(label("Phân loại món ăn", 13, MUTED, true), outside(0, 7));
        categorySpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, CATEGORIES);
        categorySpinner.setAdapter(adapter);
        categorySpinner.setBackground(outlined(CREAM, 12, LINE));
        categorySpinner.setPadding(dp(12), dp(7), dp(10), dp(7));
        editor.addView(categorySpinner, outside(0, 12));
        Button choosePhoto = btn("📷  Thêm ảnh món ăn", Color.rgb(236, 243, 235), GREEN);
        editor.addView(choosePhoto, outside(0, 8));
        choosePhoto.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_PHOTO);
        });
        photoArea = column();
        editor.addView(photoArea, outside(0, 9));
        Button save = btn("✓   Lưu món ăn", RUST, WHITE);
        editor.addView(save, outside(0, 2));
        save.setOnClickListener(v -> saveRecipe());
        editor.setVisibility(View.GONE);

        // COLLECTION
        LinearLayout collectionTitle = row();
        root.addView(collectionTitle, outside(9, 6));
        summary = label("Bộ sưu tập của tôi", 22, INK, true);
        collectionTitle.addView(summary, new LinearLayout.LayoutParams(0, -2, 1));
        TextView collectionIcon = label("♥", 19, RUST, true);
        collectionTitle.addView(collectionIcon);
        root.addView(label("Những món ngon bạn muốn giữ mãi", 13, MUTED, false), outside(0, 8));
        list = column();
        root.addView(list);

        // BACKUP SECTION
        LinearLayout backup = column();
        backup.setPadding(dp(17), dp(18), dp(17), dp(18));
        backup.setBackground(outlined(WHITE, 18, LINE));
        root.addView(backup, outside(26, 4));
        backup.addView(label("☁   Công thức luôn bên bạn", 18, INK, true));
        backup.addView(label("Sao lưu trước khi đổi điện thoại hoặc gỡ ứng dụng. Bạn có thể chọn Google Drive để lưu tệp JSON.", 13, MUTED, false), outside(8, 12));
        Button export = btn("↑   Sao lưu công thức", GREEN, WHITE);
        Button restore = btn("↓   Khôi phục bản sao lưu", PALE, RUST);
        backup.addView(export, outside(0, 9));
        backup.addView(restore, outside(0, 0));
        export.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "SoTayNauAn-SaoLuu.json");
            startActivityForResult(intent, REQUEST_EXPORT);
        });
        restore.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Khôi phục công thức")
            .setMessage("Hãy chọn tệp JSON đã sao lưu. Bạn sẽ được hỏi Gộp hay Thay thế trước khi lưu.")
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Chọn tệp", (d, which) -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(intent, REQUEST_IMPORT);
            }).show());
        TextView foot = label("Nấu bằng cả trái tim  ♥", 12, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot, outside(23, 0));
    }

    private EditText field(String hint, int lines) {
        EditText e = new EditText(this);
        e.setTextSize(15);
        e.setTextColor(INK);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setPadding(dp(13), dp(10), dp(13), dp(10));
        e.setBackground(outlined(CREAM, 12, LINE));
        if (lines == 1) e.setSingleLine(true);
        else { e.setMinLines(lines); e.setGravity(Gravity.TOP); }
        return e;
    }

    private void refreshFilters() {
        if (filterRow == null) return;
        filterRow.removeAllViews();
        for (String item : FILTERS) {
            boolean selected = item.equals(activeFilter);
            TextView chip = label(item, 13, selected ? WHITE : INK, selected);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(15), dp(10), dp(15), dp(10));
            chip.setBackground(rounded(selected ? RUST : WHITE, 28));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.setMargins(0, 0, dp(8), 0);
            filterRow.addView(chip, p);
            chip.setOnClickListener(v -> {
                activeFilter = item;
                refreshFilters();
                refreshList();
            });
        }
    }

    private void clearEditor() {
        editingIndex = -1;
        selectedPhoto = "";
        nameInput.setText("");
        ingredientInput.setText("");
        instructionInput.setText("");
        categorySpinner.setSelection(0);
        editorTitle.setText("Thêm công thức");
        refreshPhoto();
    }

    private void refreshPhoto() {
        photoArea.removeAllViews();
        if (selectedPhoto.isEmpty()) return;
        File photo = photoFile(selectedPhoto);
        if (!photo.isFile()) return;
        Bitmap imageBitmap = BitmapFactory.decodeFile(photo.getAbsolutePath());
        if (imageBitmap == null) return;
        ImageView photoView = new ImageView(this);
        photoView.setImageBitmap(imageBitmap);
        photoView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photoView.setBackground(rounded(PALE, 15));
        photoView.setClipToOutline(true);
        photoArea.addView(photoView, new LinearLayout.LayoutParams(-1, dp(160)));
        Button remove = btn("Bỏ ảnh này", PALE, RUST);
        photoArea.addView(remove, outside(7, 0));
        remove.setOnClickListener(v -> { selectedPhoto = ""; refreshPhoto(); });
    }

    private void saveRecipe() {
        String name = nameInput.getText().toString().trim();
        if (name.isEmpty()) {
            nameInput.setError("Hãy nhập tên món ăn");
            nameInput.requestFocus();
            return;
        }
        try {
            JSONObject item = new JSONObject();
            item.put("ten", name);
            item.put("nguyenlieu", ingredientInput.getText().toString().trim());
            item.put("cachlam", instructionInput.getText().toString().trim());
            item.put("loai", CATEGORIES[categorySpinner.getSelectedItemPosition()]);
            item.put("anh", selectedPhoto);
            if (editingIndex >= 0) recipes.put(editingIndex, item);
            else recipes.put(item);
            persist();
            clearEditor();
            editor.setVisibility(View.GONE);
            refreshList();
            Toast.makeText(this, "Đã lưu công thức!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Không thể lưu công thức", Toast.LENGTH_LONG).show();
        }
    }

    private void editRecipe(int index) {
        JSONObject item = recipes.optJSONObject(index);
        if (item == null) return;
        editingIndex = index;
        nameInput.setText(item.optString("ten"));
        ingredientInput.setText(item.optString("nguyenlieu"));
        instructionInput.setText(item.optString("cachlam"));
        String kind = item.optString("loai", "Món Việt");
        for (int i = 0; i < CATEGORIES.length; i++)
            if (CATEGORIES[i].equals(kind)) { categorySpinner.setSelection(i); break; }
        selectedPhoto = item.optString("anh", "");
        editorTitle.setText("Chỉnh sửa công thức");
        refreshPhoto();
        editor.setVisibility(View.VISIBLE);
        scrollView.post(() -> scrollView.smoothScrollTo(0, editor.getTop()));
    }

    private void deleteRecipe(int index) {
        JSONObject item = recipes.optJSONObject(index);
        if (item == null) return;
        new AlertDialog.Builder(this)
            .setTitle("Xóa công thức?")
            .setMessage("Bạn có chắc muốn xóa món “" + item.optString("ten") + "”? Hãy sao lưu nếu muốn giữ lại.")
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Xóa", (d, which) -> {
                JSONArray next = new JSONArray();
                for (int i = 0; i < recipes.length(); i++)
                    if (i != index) next.put(recipes.opt(i));
                recipes = next;
                persist();
                clearEditor();
                editor.setVisibility(View.GONE);
                refreshList();
            }).show();
    }

    private String categoryEmoji(String kind) {
        if (kind.equals("Món Việt")) return "🍜";
        if (kind.equals("Món Âu")) return "🍝";
        if (kind.equals("Món Á")) return "🍱";
        if (kind.equals("Món chay")) return "🥗";
        return "🍲";
    }

    private void showDetails(JSONObject item) {
        String ingredients = item.optString("nguyenlieu", "").trim();
        String how = item.optString("cachlam", "").trim();
        if (ingredients.isEmpty()) ingredients = "Chưa nhập nguyên liệu";
        if (how.isEmpty()) how = "Chưa nhập cách chế biến";
        new AlertDialog.Builder(this)
            .setTitle(item.optString("ten"))
            .setMessage("🥬 NGUYÊN LIỆU\n" + ingredients + "\n\n👩‍🍳 CÁCH LÀM\n" + how)
            .setPositiveButton("Đóng", null)
            .show();
    }

    private void refreshList() {
        if (list == null) return;
        list.removeAllViews();
        countBadge.setText(recipes.length() + " món");
        String query = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int visible = 0;
        for (int i = recipes.length() - 1; i >= 0; i--) {
            JSONObject item = recipes.optJSONObject(i);
            if (item == null) continue;
            String title = item.optString("ten", "Món ăn");
            String kind = item.optString("loai", "Món Việt");
            if (!activeFilter.equals("Tất cả") && !activeFilter.equals(kind)) continue;
            String content = title + " " + item.optString("nguyenlieu", "");
            if (!content.toLowerCase(Locale.ROOT).contains(query)) continue;
            visible++;
            final int recipeIndex = i;

            LinearLayout card = column();
            card.setBackground(rounded(WHITE, 20));
            card.setElevation(dp(3));
            card.setClipToOutline(true);
            list.addView(card, outside(10, 8));

            File photo = photoFile(item.optString("anh", ""));
            Bitmap bitmap = photo.isFile() ? BitmapFactory.decodeFile(photo.getAbsolutePath()) : null;
            if (bitmap != null) {
                ImageView image = new ImageView(this);
                image.setImageBitmap(bitmap);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                card.addView(image, new LinearLayout.LayoutParams(-1, dp(155)));
            } else {
                LinearLayout cover = row();
                cover.setPadding(dp(18), dp(13), dp(16), dp(13));
                cover.setBackground(gradient(Color.rgb(249, 223, 191), Color.rgb(255, 241, 219), 17));
                card.addView(cover, new LinearLayout.LayoutParams(-1, dp(115)));
                TextView illustration = label(categoryEmoji(kind), 54, INK, false);
                illustration.setGravity(Gravity.CENTER);
                cover.addView(illustration, new LinearLayout.LayoutParams(dp(85), -1));
                LinearLayout noPhoto = column();
                cover.addView(noPhoto, weighted(1, 0));
                noPhoto.addView(label("BẾP NHÀ MÌNH", 12, RUST, true), outside(18, 4));
                noPhoto.addView(label("Món ngon\nmỗi ngày", 19, INK, true));
            }
            LinearLayout cardBody = column();
            cardBody.setPadding(dp(16), dp(13), dp(16), dp(16));
            card.addView(cardBody);
            LinearLayout titleRow = row();
            cardBody.addView(titleRow);
            TextView dishName = label(title, 20, INK, true);
            titleRow.addView(dishName, weighted(1, 7));
            TextView category = label(kind, 11, GREEN, true);
            category.setPadding(dp(9), dp(6), dp(9), dp(6));
            category.setBackground(rounded(Color.rgb(233, 243, 230), 15));
            titleRow.addView(category);
            String ingredients = item.optString("nguyenlieu", "").trim();
            if (ingredients.isEmpty()) ingredients = "Chưa nhập nguyên liệu";
            TextView intro = label("🥬  " + ingredients, 14, MUTED, false);
            intro.setSingleLine(true);
            intro.setEllipsize(android.text.TextUtils.TruncateAt.END);
            cardBody.addView(intro, outside(9, 12));
            TextView divider = label("", 1, LINE, false);
            divider.setBackgroundColor(LINE);
            cardBody.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            LinearLayout actionRow = row();
            cardBody.addView(actionRow, outside(10, 0));
            Button see = btn("Xem công thức  ›", PALE, RUST);
            Button edit = btn("✎ Sửa", Color.rgb(235, 243, 236), GREEN);
            Button delete = btn("✕", Color.rgb(252, 238, 233), RUST);
            actionRow.addView(see, weighted(1.5f, 7));
            actionRow.addView(edit, weighted(1f, 7));
            actionRow.addView(delete, new LinearLayout.LayoutParams(dp(48), dp(46)));
            see.setOnClickListener(v -> showDetails(item));
            edit.setOnClickListener(v -> editRecipe(recipeIndex));
            delete.setOnClickListener(v -> deleteRecipe(recipeIndex));
            card.setOnClickListener(v -> showDetails(item));
        }
        if (visible == 0) {
            LinearLayout empty = column();
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(20), dp(28), dp(20), dp(30));
            empty.setBackground(outlined(WHITE, 18, LINE));
            list.addView(empty, outside(10, 5));
            TextView emoji = label("📖", 48, RUST, false);
            emoji.setGravity(Gravity.CENTER);
            empty.addView(emoji);
            TextView message = label("Chưa có công thức phù hợp", 17, INK, true);
            message.setGravity(Gravity.CENTER);
            empty.addView(message, outside(10, 6));
            TextView helper = label("Nhấn “Thêm công thức mới” để bắt đầu nhé!", 13, MUTED, false);
            helper.setGravity(Gravity.CENTER);
            empty.addView(helper);
        }
        summary.setText("Bộ sưu tập của tôi  (" + visible + ")");
    }

    private void persist() {
        store.edit().putString("data", recipes.toString()).apply();
    }

    private File photoFile(String filename) {
        if (filename == null || !filename.startsWith("photo_") || !filename.endsWith(".jpg")
                || filename.contains("/") || filename.contains("\\")) {
            return new File(getFilesDir(), "__missing_photo__");
        }
        return new File(getFilesDir(), filename);
    }

    private String writePhoto(byte[] bytes) throws Exception {
        String filename = "photo_" + UUID.randomUUID() + ".jpg";
        FileOutputStream output = new FileOutputStream(photoFile(filename));
        try { output.write(bytes); } finally { output.close(); }
        return filename;
    }

    private String importPhoto(Uri uri) throws Exception {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream probe = getContentResolver().openInputStream(uri);
        try { BitmapFactory.decodeStream(probe, null, options); } finally { if (probe != null) probe.close(); }
        int scale = 1;
        while (options.outWidth / scale > 1400 || options.outHeight / scale > 1400) scale *= 2;
        options.inJustDecodeBounds = false;
        options.inSampleSize = scale;
        InputStream source = getContentResolver().openInputStream(uri);
        Bitmap image;
        try { image = BitmapFactory.decodeStream(source, null, options); }
        finally { if (source != null) source.close(); }
        if (image == null) throw new Exception("Ảnh không hợp lệ");
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 78, output);
        image.recycle();
        return writePhoto(output.toByteArray());
    }

    private byte[] readBytes(File file) throws Exception {
        FileInputStream input = new FileInputStream(file);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        try { while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n); }
        finally { input.close(); }
        return output.toByteArray();
    }

    private void exportBackup(Uri uri) {
        try {
            JSONArray exported = new JSONArray();
            for (int i = 0; i < recipes.length(); i++) {
                JSONObject original = recipes.optJSONObject(i);
                if (original == null) continue;
                JSONObject item = new JSONObject(original.toString());
                File photo = photoFile(item.optString("anh", ""));
                if (photo.isFile()) {
                    item.put("imageBase64", Base64.encodeToString(readBytes(photo), Base64.NO_WRAP));
                }
                exported.put(item);
            }
            JSONObject backup = new JSONObject();
            backup.put("format", "SoTayNauAn");
            backup.put("version", 2);
            backup.put("recipes", exported);
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new Exception("Không thể mở tệp");
            try { out.write(backup.toString(2).getBytes(StandardCharsets.UTF_8)); }
            finally { out.close(); }
            Toast.makeText(this, "Đã xuất bản sao lưu", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Sao lưu thất bại: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void importBackup(Uri uri) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Không mở được tệp");
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            try {
                while ((n = in.read(buffer)) != -1) {
                    if (output.size() + n > 80 * 1024 * 1024) throw new Exception("Tệp sao lưu quá lớn");
                    output.write(buffer, 0, n);
                }
            } finally { in.close(); }
            JSONObject backup = new JSONObject(output.toString("UTF-8"));
            if (!"SoTayNauAn".equals(backup.optString("format"))) {
                throw new Exception("Không đúng định dạng sao lưu Sổ Tay Nấu Ăn");
            }
            JSONArray restored = backup.getJSONArray("recipes");
            if (restored.length() > 2000) throw new Exception("Quá nhiều công thức");
            new AlertDialog.Builder(this)
                .setTitle("Nhập " + restored.length() + " công thức")
                .setMessage("Chọn Gộp để giữ món đang có, hoặc Thay thế để dùng danh sách từ bản sao lưu.")
                .setNegativeButton("Hủy", null)
                .setNeutralButton("Thay thế", (d, w) -> applyBackup(restored, false))
                .setPositiveButton("Gộp", (d, w) -> applyBackup(restored, true))
                .show();
        } catch (Exception e) {
            Toast.makeText(this, "Không đọc được bản sao lưu: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void applyBackup(JSONArray source, boolean merge) {
        try {
            JSONArray next = new JSONArray();
            if (merge) {
                for (int i = 0; i < recipes.length(); i++) next.put(recipes.opt(i));
            }
            for (int i = 0; i < source.length(); i++) {
                JSONObject original = source.optJSONObject(i);
                if (original == null) continue;
                JSONObject item = new JSONObject();
                item.put("ten", original.optString("ten"));
                item.put("nguyenlieu", original.optString("nguyenlieu"));
                item.put("cachlam", original.optString("cachlam"));
                item.put("loai", original.optString("loai", "Món Việt"));
                String encoded = original.optString("imageBase64", "");
                if (!encoded.isEmpty()) {
                    byte[] photo = Base64.decode(encoded, Base64.DEFAULT);
                    if (photo.length > 12 * 1024 * 1024) throw new Exception("Có ảnh quá lớn");
                    item.put("anh", writePhoto(photo));
                } else {
                    item.put("anh", "");
                }
                next.put(item);
            }
            recipes = next;
            persist();
            clearEditor();
            editor.setVisibility(View.GONE);
            refreshList();
            Toast.makeText(this, "Khôi phục thành công", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Khôi phục thất bại: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_PHOTO) {
            try {
                selectedPhoto = importPhoto(uri);
                refreshPhoto();
            } catch (Exception e) {
                Toast.makeText(this, "Không thể thêm ảnh: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_EXPORT) {
            exportBackup(uri);
        } else if (requestCode == REQUEST_IMPORT) {
            importBackup(uri);
        }
    }
}
